# Vconomics Refferal Bot

How to use :

1. git clone https://github.com/dkmpostor/vconomics/
2. cd vconomics
3. npm install
4. node new.js
5. Input refferal code & Email !
6. Done

NOTE :

Use file new.js ! File index.js already fixed by developer

Required :
1. Gmail for OTP verification
2. Your time :v coz need manual verification !

Thank you
